import logo from './logo.svg';
import './App.css';
import Button from "./components/ui/button/Button";
import CardList from "./components/CardList";
import React, {useEffect, useState} from "react";

function App() {

    const cards = [
        {
            id: 0,
            title: "Card 1",
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin ultrices velit sed molestie congue. Sed dignissim massa ultrices erat mattis, nec dapibus mauris ultrices."
        },
        {
            id: 1,
            title: "Card 2",
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eleifend diam in rutrum rhoncus. Duis efficitur nibh non leo sodales vestibulum. Duis quis tempor metus."
        },
        {
            id: 2,
            title: "Card 3",
            content: "Pellentesque lorem metus, convallis a vulputate quis, iaculis ac quam. In euismod gravida nisl, quis tincidunt odio bibendum id. Donec vel tempus erat."
        }
    ]

    const [colors, setColors] = useState(["#333", "#333", "#333"])
    const [index, setIndex] = useState(-1)

    useEffect(() => {
        if (index > 2) setIndex(0)
        let newColors = []
        cards.forEach((card, idx) => {
            if (idx === index) newColors.push("#444")
            else newColors.push("#333")
        })
        setColors(newColors)
    }, [index])


    return (
        <div className="App">
            <CardList cards={cards} colors={colors}/>
            <div className={"mt-3"}>
                <Button onClick={() => setIndex(index + 1)}>Click me!</Button>
            </div>
        </div>
    );
}

export default App;
